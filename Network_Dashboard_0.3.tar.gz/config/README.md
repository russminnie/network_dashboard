# ./config

To use a configuration file with the application, include this directory along with a sample configuration file and documentation in the packaged mPower custom application.