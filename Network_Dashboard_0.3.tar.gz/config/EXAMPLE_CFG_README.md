# Example Configuration File Documentation

File format is JSON with the following key values:

### fruit
 Name of fruit. String

### variety
 Fruit variety. String

# Example JSON Config File:
```
{
    "fruit":"apple",
    "variety":"red delicious"
}
```