# ./provisioning

If the application requires installed dependencies include a ./provisioning directory, the edited `p_manifest.json` file, and ipk packages when building the application.